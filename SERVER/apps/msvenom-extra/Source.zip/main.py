from rich import print

print("[green] msvenom-extra ha sido instalado correctamente [/green]")